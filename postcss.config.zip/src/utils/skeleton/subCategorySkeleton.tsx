import React from 'react'

export default function subCategorySkeleton() {
	return (
		<div>subCategorySkeleton</div>
	)
}
